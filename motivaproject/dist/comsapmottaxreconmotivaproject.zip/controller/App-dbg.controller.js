sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.sap.mot.tax.recon.motivaproject.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  